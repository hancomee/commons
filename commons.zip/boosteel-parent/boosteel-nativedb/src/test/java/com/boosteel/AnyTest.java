package com.boosteel;


import com.boosteel.nativedb.NativeDB;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.List;
import java.util.Map;

public class AnyTest {


    @Test
    public void run() throws Exception {
        Method m = this.getClass().getMethod("magic", null);

        String mType = m.getGenericReturnType().toString();
        mType = mType.substring(mType.indexOf("<") + 1, mType.lastIndexOf(">"));
        out(mType);
    }

    public List<Map<String, Object>> magic() {
        return null;
    }

    public void out(Object obj) {
        System.out.println(obj);
    }
}
