package com.boosteel;


import com.boosteel.nativedb.NativeDB;
import org.junit.jupiter.api.Test;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class DBTest {

    private NativeDB db = new NativeDB("jdbc:mariadb://115.23.187.44:3306/hancomee", "root", "ko9984");

    @Test
    public void run() throws Exception {
        String sql = "SELECT * FROM jinyeosoo_customer this ORDER BY this.datetime DESC";
        db.doStmt(s -> {
            ResultSet rs = s.executeQuery(sql);
            rs.next();
            ResultSetMetaData resultSetMetaData = rs.getMetaData();
            out(resultSetMetaData.getTableName(1));
            out(resultSetMetaData.getCatalogName(1));
            out(resultSetMetaData.getSchemaName(1));
        });
    }

    public void out(Object obj) {
        System.out.println(obj);
    }
}
