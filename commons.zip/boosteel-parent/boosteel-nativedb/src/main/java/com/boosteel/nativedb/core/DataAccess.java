package com.boosteel.nativedb.core;

import com.boosteel.nativedb.reflect.ReflectObject;
import com.boosteel.util.IAccess;
import com.boosteel.util.support.MapAccess;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.*;

import static com.boosteel.nativedb.core.DataConverter.data_by_dType;

public class DataAccess {

    public static final List<Map<String, Object>> readAll(ResultSet rs) {
        List<Map<String, Object>> result = new ArrayList<>();
        try {
            while (rs.next())
                result.add(read(rs, new MapAccess()));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    public static final <T> List<T> readAll(ResultSet rs, Class<T> clazz) {
        List<T> result = new ArrayList<>();
        try {
            while (rs.next())
                result.add(read(rs, ReflectObject.createAccess(clazz.newInstance())));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return result;
    }

    /*
     *  1:N 조인 결과 담기
     */
    public static final List<Map<String, Object>> readJoin(ResultSet _rs, String manys) {
        return readJoin(_rs, new HashSet<>(Arrays.asList(manys.split(" "))));
    }

    public static final List<Map<String, Object>> readJoin(ResultSet _rs, Set<String> manys) {

        // id를 기준으로 담는 결과 맵
        Map<String, Map<String, Object>> result = new HashMap<>();


        try (ResultSet rs = _rs) {

            // 한 행의 결과를 모두 담을 맵
            Map<String, Map<String, Object>> buffer;

            ResultSetMetaData meta = rs.getMetaData();
            int i, len = meta.getColumnCount() + 1;
            String label, tableName;

            // ① 행 조회
            while (rs.next()) {

                buffer = new HashMap<>();
                i = 1;

                // ② 컬럼 조회
                for (; i < len; i++) {

                    label = meta.getColumnLabel(i);
                    tableName = meta.getTableName(i);

                    Map<String, Object> temp;

                    /*
                     *  _ 로 시작하는 table은 맵핑에서 제외한다.
                     *
                     *  일단 테이블명당 map을 하나씩 만들어서 값을 전부 담는다.
                     *
                     */
                    if (tableName.charAt(0) != '_') {
                        if ((temp = buffer.get(tableName)) == null) {
                            buffer.put(tableName, temp = new HashMap<>());
                        }
                        temp.put(label, data_by_dType(rs, meta.getColumnTypeName(i), i));
                    }
                }

                String id = buffer.get("this").get("id").toString();
                Map<String, Object> _r = result.get(id);
                if (_r == null) {
                    result.put(id, _r = buffer.get("this"));
                }

                buffer.remove("this");

                for (String key : buffer.keySet()) {

                    // many가 아닌 경우
                    if (!manys.contains(key)) {
                        if (!_r.containsKey(key))
                            _r.put(key, buffer.get(key));
                    } else {
                        List list = (List) _r.get(key);
                        if (list == null) {
                            _r.put(key, list = new ArrayList<>());
                        }
                        list.add(buffer.get(key));
                    }
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return new ArrayList<>(result.values());
    }

    public static final <T> T read(ResultSet rs, IAccess<T> access) {
        try {

            ResultSetMetaData meta = rs.getMetaData();
            int len = meta.getColumnCount();
            String label, tableName;

            while (len > 0) {
                label = meta.getColumnLabel(len);
                tableName = meta.getTableName(len);

                /*
                 *  tableName을 통해 객체를 선별한다.
                 *  _ 로 시작하는 table은 맵핑에서 제외한다.
                 */
                if (tableName.isEmpty())
                    access.set(label, data_by_dType(rs, meta.getColumnTypeName(len), len));
                else if (tableName.charAt(0) != '_') {
                    if (tableName.equals("this")) {
                        access.set(label, data_by_dType(rs, meta.getColumnTypeName(len), len));
                    }
                    // 하위 멤버 빈일 경우
                    else {
                        access.set(tableName + "." + label, data_by_dType(rs, meta.getColumnTypeName(len), len));
                    }
                }
                len--;
            }

            return access.target();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
