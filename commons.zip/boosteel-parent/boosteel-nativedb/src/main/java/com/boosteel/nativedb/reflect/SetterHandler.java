package com.boosteel.nativedb.reflect;

public interface SetterHandler {
    void set(Object target, Object val);
}
